import { Router, Request, Response } from "express";
import { storagePut } from "../storage";
import { nanoid } from "nanoid";

const router = Router();

router.post("/upload", async (req: Request, res: Response) => {
  try {
    // Get file from request (assuming multipart/form-data)
    const file = (req as any).file;
    
    if (!file) {
      return res.status(400).json({ error: "No file provided" });
    }

    // Validate file type
    if (!file.mimetype.startsWith("image/")) {
      return res.status(400).json({ error: "File must be an image" });
    }

    // Generate unique filename
    const filename = `${nanoid()}-${file.originalname}`;
    
    // Upload to S3
    const { url } = await storagePut(
      `artworks/${filename}`,
      file.buffer,
      file.mimetype
    );

    res.json({ url });
  } catch (error) {
    console.error("Upload error:", error);
    res.status(500).json({ error: "Failed to upload file" });
  }
});

export default router;
