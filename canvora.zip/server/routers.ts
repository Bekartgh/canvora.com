import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";
import { desc, eq, and, sql } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  user: router({
    getProfile: protectedProcedure.query(async ({ ctx }) => {
      const user = await db.getUserById(ctx.user.id);
      if (!user) throw new TRPCError({ code: "NOT_FOUND" });
      return user;
    }),

    updateProfile: protectedProcedure
      .input(z.object({
        name: z.string().optional(),
        bio: z.string().optional(),
        userType: z.enum(["artist", "collector"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.updateUserProfile(ctx.user.id, input);
        return { success: true };
      }),

    getPublicProfile: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        const user = await db.getUserById(input.userId);
        if (!user) throw new TRPCError({ code: "NOT_FOUND" });
        return user;
      }),
  }),

  artwork: router({
    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string(),
        imageUrl: z.string().url(),
        price: z.number().positive(),
        category: z.string(),
        tags: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.userType !== "artist") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only artists can upload artworks" });
        }
        
        const { artworks: artworksTable } = await import("../drizzle/schema");
        const dbInstance = await db.getDb();
        if (!dbInstance) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        
        const result = await dbInstance.insert(artworksTable).values({
          artistId: ctx.user.id,
          title: input.title,
          description: input.description,
          imageUrl: input.imageUrl,
          price: input.price as any,
          category: input.category,
          tags: input.tags ? JSON.stringify(input.tags.split(",")) : null,
        });
        
        return { success: true, artworkId: (result as any).insertId };
      }),

    getById: publicProcedure
      .input(z.object({ artworkId: z.number() }))
      .query(async ({ input }) => {
        const artwork = await db.getArtworkById(input.artworkId);
        if (!artwork) throw new TRPCError({ code: "NOT_FOUND" });
        return artwork;
      }),

    getFeed: publicProcedure
      .input(z.object({
        limitVal: z.number().default(10),
        offsetVal: z.number().default(0),
      }))
      .query(async ({ input }) => {
        const dbInstance = await db.getDb();
        if (!dbInstance) return [];
        
        const { artworks: artworksTable } = await import("../drizzle/schema");
        const results = await dbInstance.select().from(artworksTable)
          .orderBy(desc(artworksTable.createdAt))
          .limit(input.limitVal)
          .offset(input.offsetVal);
        
        return results;
      }),

    delete: protectedProcedure
      .input(z.object({ artworkId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const artwork = await db.getArtworkById(input.artworkId);
        if (!artwork) throw new TRPCError({ code: "NOT_FOUND" });
        
        if (artwork.artistId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        
        const dbInstance = await db.getDb();
        if (!dbInstance) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        
        const { artworks: artworksTable } = await import("../drizzle/schema");
        await dbInstance.delete(artworksTable).where(eq(artworksTable.id, input.artworkId));
        return { success: true };
      }),
  }),

  like: router({
    toggle: protectedProcedure
      .input(z.object({ artworkId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const hasLiked = await db.hasUserLikedArtwork(ctx.user.id, input.artworkId);
        const dbInstance = await db.getDb();
        if (!dbInstance) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        
        const { likes: likesTable, artworks: artworksTable } = await import("../drizzle/schema");
        
        if (hasLiked) {
          await dbInstance.delete(likesTable)
            .where(and(eq(likesTable.userId, ctx.user.id), eq(likesTable.artworkId, input.artworkId)));
          
          await dbInstance.update(artworksTable)
            .set({ likeCount: sql`likeCount - 1` })
            .where(eq(artworksTable.id, input.artworkId));
        } else {
          await dbInstance.insert(likesTable).values({
            userId: ctx.user.id,
            artworkId: input.artworkId,
          });
          
          await dbInstance.update(artworksTable)
            .set({ likeCount: sql`likeCount + 1` })
            .where(eq(artworksTable.id, input.artworkId));
        }
        
        return { liked: !hasLiked };
      }),

    getCount: publicProcedure
      .input(z.object({ artworkId: z.number() }))
      .query(async ({ input }) => {
        const count = await db.getArtworkLikeCount(input.artworkId);
        return { count };
      }),
  }),

  follow: router({
    toggle: protectedProcedure
      .input(z.object({ artistId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.id === input.artistId) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Cannot follow yourself" });
        }
        
        const isFollowing = await db.isFollowing(ctx.user.id, input.artistId);
        const dbInstance = await db.getDb();
        if (!dbInstance) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        
        const { follows: followsTable, users: usersTable } = await import("../drizzle/schema");
        
        if (isFollowing) {
          await dbInstance.delete(followsTable)
            .where(and(eq(followsTable.followerId, ctx.user.id), eq(followsTable.followingId, input.artistId)));
          
          await dbInstance.update(usersTable)
            .set({ followerCount: sql`followerCount - 1` })
            .where(eq(usersTable.id, input.artistId));
          
          await dbInstance.update(usersTable)
            .set({ followingCount: sql`followingCount - 1` })
            .where(eq(usersTable.id, ctx.user.id));
        } else {
          await dbInstance.insert(followsTable).values({
            followerId: ctx.user.id,
            followingId: input.artistId,
          });
          
          await dbInstance.update(usersTable)
            .set({ followerCount: sql`followerCount + 1` })
            .where(eq(usersTable.id, input.artistId));
          
          await dbInstance.update(usersTable)
            .set({ followingCount: sql`followingCount + 1` })
            .where(eq(usersTable.id, ctx.user.id));
        }
        
        return { following: !isFollowing };
      }),

    isFollowing: publicProcedure
      .input(z.object({ followerId: z.number(), followingId: z.number() }))
      .query(async ({ input }) => {
        const isFollowing = await db.isFollowing(input.followerId, input.followingId);
        return { isFollowing };
      }),
  }),

  comment: router({
    create: protectedProcedure
      .input(z.object({
        artworkId: z.number(),
        content: z.string(),
        parentCommentId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const dbInstance = await db.getDb();
        if (!dbInstance) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        
        const { comments: commentsTable, artworks: artworksTable } = await import("../drizzle/schema");
        
        const result = await dbInstance.insert(commentsTable).values({
          userId: ctx.user.id,
          artworkId: input.artworkId,
          parentCommentId: input.parentCommentId || null,
          content: input.content,
        });
        
        await dbInstance.update(artworksTable)
          .set({ commentCount: sql`commentCount + 1` })
          .where(eq(artworksTable.id, input.artworkId));
        
        return { success: true, commentId: (result as any).insertId };
      }),

    getByArtwork: publicProcedure
      .input(z.object({ artworkId: z.number() }))
      .query(async ({ input }) => {
        return await db.getArtworkComments(input.artworkId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
