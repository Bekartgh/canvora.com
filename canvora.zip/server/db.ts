import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, artworks, follows, orders, comments, likes } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
      userType: user.userType || 'collector', // Default to collector if not specified
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserProfile(userId: number, updates: { name?: string; bio?: string; profilePictureUrl?: string; userType?: 'artist' | 'collector' }) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.update(users).set(updates).where(eq(users.id, userId));
  return result;
}

export async function getUserArtworks(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db.select().from(artworks).where(eq(artworks.artistId, userId));
  return result;
}

export async function getFollowingCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db.select().from(follows).where(eq(follows.followerId, userId));
  return result.length;
}

export async function getFollowerCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db.select().from(follows).where(eq(follows.followingId, userId));
  return result.length;
}

export async function isFollowing(followerId: number, followingId: number) {
  const db = await getDb();
  if (!db) return false;

  const result = await db.select().from(follows)
    .where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)))
    .limit(1);
  return result.length > 0;
}

export async function getArtworkById(artworkId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(artworks).where(eq(artworks.id, artworkId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getArtworkComments(artworkId: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db.select().from(comments).where(eq(comments.artworkId, artworkId));
  return result;
}

export async function getArtworkLikeCount(artworkId: number) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db.select().from(likes).where(eq(likes.artworkId, artworkId));
  return result.length;
}

export async function hasUserLikedArtwork(userId: number, artworkId: number) {
  const db = await getDb();
  if (!db) return false;

  const result = await db.select().from(likes)
    .where(and(eq(likes.userId, userId), eq(likes.artworkId, artworkId)))
    .limit(1);
  return result.length > 0;
}

export async function getUserOrders(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db.select().from(orders).where(eq(orders.collectorId, userId));
  return result;
}

export async function getArtistSales(artistId: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db.select().from(orders).where(eq(orders.artistId, artistId));
  return result;
}
