import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { Loader2, Trash2, Plus, Eye } from "lucide-react";
import { toast } from "sonner";

export default function ArtistDashboard() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [artworks, setArtworks] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const deleteArtworkMutation = trpc.artwork.delete.useMutation();

  // Fetch artworks on mount
  useEffect(() => {
    const fetchArtworks = async () => {
      try {
        setIsLoading(true);
        // This would need to be added to the backend
        // For now, we'll show a placeholder
        setArtworks([]);
      } catch (error) {
        console.error("Failed to fetch artworks:", error);
        toast.error("Failed to load artworks");
      } finally {
        setIsLoading(false);
      }
    };

    if (user?.userType === "artist") {
      fetchArtworks();
    }
  }, [user]);

  const handleDelete = async (artworkId: number) => {
    if (!confirm("Are you sure you want to delete this artwork?")) return;

    try {
      await deleteArtworkMutation.mutateAsync({ artworkId });
      setArtworks(artworks.filter((a) => a.id !== artworkId));
      toast.success("Artwork deleted successfully");
    } catch (error) {
      console.error("Delete error:", error);
      toast.error("Failed to delete artwork");
    }
  };

  if (user?.userType !== "artist") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Artist Dashboard</CardTitle>
            <CardDescription>This page is for artists only</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/")} className="w-full">
              Go Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold">Artist Dashboard</h1>
            <p className="text-muted-foreground mt-2">Manage your uploaded artworks</p>
          </div>
          <Button onClick={() => navigate("/upload")} size="lg">
            <Plus className="mr-2 h-4 w-4" />
            Upload New Artwork
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Artworks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{artworks.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Views</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {artworks.reduce((sum, a) => sum + (a.viewCount || 0), 0)}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Likes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {artworks.reduce((sum, a) => sum + (a.likeCount || 0), 0)}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Artworks Grid */}
        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : artworks.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground mb-4">You haven't uploaded any artworks yet</p>
              <Button onClick={() => navigate("/upload")}>
                <Plus className="mr-2 h-4 w-4" />
                Upload Your First Artwork
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {artworks.map((artwork) => (
              <Card key={artwork.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative aspect-square overflow-hidden bg-muted">
                  <img
                    src={artwork.imageUrl}
                    alt={artwork.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => navigate(`/artwork/${artwork.id}`)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(artwork.id)}
                      disabled={deleteArtworkMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <CardContent className="pt-4">
                  <h3 className="font-semibold truncate">{artwork.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                    {artwork.description}
                  </p>
                  <div className="flex justify-between items-center mb-3">
                    <Badge variant="outline">{artwork.category}</Badge>
                    <span className="font-semibold">${artwork.price.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>👁️ {artwork.viewCount || 0} views</span>
                    <span>❤️ {artwork.likeCount || 0} likes</span>
                    <span>💬 {artwork.commentCount || 0} comments</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
