import { useState, useEffect, useRef, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, MessageCircle, Share2, Bookmark } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

interface ArtworkCard {
  id: number;
  title: string;
  imageUrl: string;
  price: number;
  category: string;
  likeCount: number;
  commentCount: number;
  artist: {
    id: number;
    name: string;
    profilePictureUrl?: string;
  };
}

export default function Feed() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [feedType, setFeedType] = useState<"for-you" | "trending" | "following">("for-you");
  const [artworks, setArtworks] = useState<ArtworkCard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [likedArtworks, setLikedArtworks] = useState<Set<number>>(new Set());
  const containerRef = useRef<HTMLDivElement>(null);

  const likeMutation = trpc.like.toggle.useMutation();
  const followMutation = trpc.follow.toggle.useMutation();

  // Fetch artworks using tRPC hook
  const { data: feedData, isLoading: isFeedLoading } = trpc.artwork.getFeed.useQuery({
    limitVal: 20,
    offsetVal: 0,
  });

  useEffect(() => {
    if (feedData) {
      setArtworks(feedData as any);
      setIsLoading(false);
    } else {
      setIsLoading(isFeedLoading);
    }
  }, [feedData, isFeedLoading]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setCurrentIndex((prev) => Math.max(0, prev - 1));
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        setCurrentIndex((prev) => Math.min(artworks.length - 1, prev + 1));
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [artworks.length]);

  // Scroll to current artwork
  useEffect(() => {
    if (containerRef.current) {
      const element = containerRef.current.children[currentIndex] as HTMLElement;
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }, [currentIndex]);

  const handleLike = async (artworkId: number) => {
    if (!user) {
      toast.error("Please log in to like artworks");
      return;
    }

    try {
      const result = await likeMutation.mutateAsync({ artworkId });
      setLikedArtworks((prev) => {
        const newSet = new Set(prev);
        if (result.liked) {
          newSet.add(artworkId);
        } else {
          newSet.delete(artworkId);
        }
        return newSet;
      });
    } catch (error) {
      console.error("Like error:", error);
      toast.error("Failed to like artwork");
    }
  };

  const handleFollow = async (artistId: number) => {
    if (!user) {
      toast.error("Please log in to follow artists");
      return;
    }

    try {
      await followMutation.mutateAsync({ artistId });
      toast.success("Following artist!");
    } catch (error) {
      console.error("Follow error:", error);
      toast.error("Failed to follow artist");
    }
  };

  const currentArtwork = artworks[currentIndex];

  return (
    <div className="min-h-screen bg-background">
      {/* Tabs */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="max-w-6xl mx-auto px-4">
          <Tabs
            value={feedType}
            onValueChange={(value) => setFeedType(value as any)}
            className="w-full"
          >
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="for-you">For You</TabsTrigger>
              <TabsTrigger value="trending">Trending</TabsTrigger>
              <TabsTrigger value="following" disabled={!user}>
                Following
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Feed Container */}
      <div
        ref={containerRef}
        className="max-h-[calc(100vh-80px)] overflow-y-auto scroll-smooth"
      >
        {isLoading ? (
          <div className="h-screen flex items-center justify-center">
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
              <p className="text-muted-foreground">Loading artworks...</p>
            </div>
          </div>
        ) : artworks.length === 0 ? (
          <div className="h-screen flex items-center justify-center">
            <div className="text-center">
              <p className="text-muted-foreground mb-4">No artworks found</p>
              <Button onClick={() => navigate("/")}>Go Home</Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4 py-4">
            {artworks.map((artwork, index) => (
              <div
                key={artwork.id}
                className={`min-h-screen flex items-center justify-center px-4 transition-opacity duration-300 ${
                  index === currentIndex ? "opacity-100" : "opacity-50"
                }`}
              >
                <Card className="w-full max-w-2xl overflow-hidden hover:shadow-xl transition-shadow">
                  {/* Image */}
                  <div className="relative aspect-video bg-muted overflow-hidden">
                    <img
                      src={artwork.imageUrl}
                      alt={artwork.title}
                      className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform"
                      onClick={() => navigate(`/artwork/${artwork.id}`)}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>

                    {/* Title Overlay */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                      <h2 className="text-2xl font-bold mb-2">{artwork.title}</h2>
                      <Badge className="mb-4">{artwork.category}</Badge>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6 space-y-4">
                    {/* Artist Info */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={artwork.artist?.profilePictureUrl} />
                          <AvatarFallback>{artwork.artist?.name?.[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{artwork.artist?.name}</p>
                          <p className="text-xs text-muted-foreground">Artist</p>
                        </div>
                      </div>
                      {user?.id !== artwork.artist?.id && (
                        <Button
                          size="sm"
                          onClick={() => handleFollow(artwork.artist.id)}
                        >
                          Follow
                        </Button>
                      )}
                    </div>

                    {/* Price */}
                    <div className="text-3xl font-bold text-primary">
                      ${artwork.price.toFixed(2)}
                    </div>

                    {/* Actions */}
                    <div className="flex gap-4 pt-4 border-t">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLike(artwork.id)}
                        className={likedArtworks.has(artwork.id) ? "text-red-500" : ""}
                      >
                        <Heart
                          className={`mr-2 h-4 w-4 ${
                            likedArtworks.has(artwork.id) ? "fill-current" : ""
                          }`}
                        />
                        {artwork.likeCount}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => navigate(`/artwork/${artwork.id}`)}
                      >
                        <MessageCircle className="mr-2 h-4 w-4" />
                        {artwork.commentCount}
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Share2 className="mr-2 h-4 w-4" />
                        Share
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Bookmark className="h-4 w-4" />
                      </Button>
                    </div>

                    {/* CTA */}
                    <Button className="w-full" onClick={() => navigate(`/artwork/${artwork.id}`)}>
                      View Details & Purchase
                    </Button>
                  </div>
                </Card>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Navigation Hint */}
      <div className="fixed bottom-4 right-4 text-xs text-muted-foreground bg-background/80 backdrop-blur px-3 py-2 rounded-lg">
        ↑↓ Scroll or use arrow keys
      </div>
    </div>
  );
}
