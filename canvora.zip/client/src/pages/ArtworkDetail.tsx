import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Heart, MessageCircle, Share2, ShoppingCart } from "lucide-react";
import { toast } from "sonner";

export default function ArtworkDetail() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/artwork/:id");
  const [artwork, setArtwork] = useState<any>(null);
  const [isLiked, setIsLiked] = useState(false);
  const [comments, setComments] = useState<any[]>([]);
  const [commentText, setCommentText] = useState("");
  const [isLoadingArtwork, setIsLoadingArtwork] = useState(true);
  const [isLoadingComments, setIsLoadingComments] = useState(true);

  const artworkId = params?.id ? parseInt(params.id) : null;

  const likeMutation = trpc.like.toggle.useMutation();
  const commentMutation = trpc.comment.create.useMutation();
  const followMutation = trpc.follow.toggle.useMutation();

  // Fetch artwork details
  useEffect(() => {
    const fetchArtwork = async () => {
      if (!artworkId) return;

      try {
        setIsLoadingArtwork(true);
        // This would call the backend API
        // For now, placeholder
        setArtwork(null);
      } catch (error) {
        console.error("Failed to fetch artwork:", error);
        toast.error("Failed to load artwork");
      } finally {
        setIsLoadingArtwork(false);
      }
    };

    fetchArtwork();
  }, [artworkId]);

  // Fetch comments using tRPC hook
  const { data: commentsData, isLoading: isLoadingCommentsQuery } = trpc.comment.getByArtwork.useQuery(
    { artworkId: artworkId || 0 },
    { enabled: !!artworkId }
  );

  useEffect(() => {
    if (commentsData) {
      setComments(commentsData);
      setIsLoadingComments(false);
    }
  }, [commentsData]);

  const handleLike = async () => {
    if (!user) {
      toast.error("Please log in to like artworks");
      return;
    }

    if (!artworkId) return;

    try {
      const result = await likeMutation.mutateAsync({ artworkId });
      setIsLiked(result.liked);
      toast.success(result.liked ? "Liked!" : "Unliked");
    } catch (error) {
      console.error("Like error:", error);
      toast.error("Failed to like artwork");
    }
  };

  const handleAddComment = async () => {
    if (!user) {
      toast.error("Please log in to comment");
      return;
    }

    if (!commentText.trim() || !artworkId) return;

    try {
      const result = await commentMutation.mutateAsync({
        artworkId,
        content: commentText,
      });

      setComments([
        ...comments,
        {
          id: result.commentId,
          content: commentText,
          userId: user.id,
          createdAt: new Date(),
        },
      ]);

      setCommentText("");
      toast.success("Comment added!");
    } catch (error) {
      console.error("Comment error:", error);
      toast.error("Failed to add comment");
    }
  };

  const handleFollow = async () => {
    if (!user || !artwork) return;

    try {
      const result = await followMutation.mutateAsync({ artistId: artwork.artistId });
      toast.success(result.following ? "Following!" : "Unfollowed");
    } catch (error) {
      console.error("Follow error:", error);
      toast.error("Failed to follow artist");
    }
  };

  if (isLoadingArtwork) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!artwork) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Artwork Not Found</CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/")} className="w-full">
              Go Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Artwork Image */}
          <div className="lg:col-span-2">
            <div className="aspect-square bg-muted rounded-lg overflow-hidden mb-6">
              <img
                src={artwork.imageUrl}
                alt={artwork.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Engagement Stats */}
            <div className="flex gap-4 mb-6">
              <Button
                variant={isLiked ? "default" : "outline"}
                onClick={handleLike}
                disabled={likeMutation.isPending}
              >
                <Heart className={`mr-2 h-4 w-4 ${isLiked ? "fill-current" : ""}`} />
                {artwork.likeCount || 0} Likes
              </Button>
              <Button variant="outline">
                <MessageCircle className="mr-2 h-4 w-4" />
                {comments.length} Comments
              </Button>
              <Button variant="outline">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>

            {/* Comments Section */}
            <Card>
              <CardHeader>
                <CardTitle>Comments</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add Comment */}
                {user && (
                  <div className="space-y-2">
                    <Textarea
                      placeholder="Add a comment..."
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      className="min-h-20"
                    />
                    <Button
                      onClick={handleAddComment}
                      disabled={!commentText.trim() || commentMutation.isPending}
                      className="w-full"
                    >
                      {commentMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Adding...
                        </>
                      ) : (
                        "Add Comment"
                      )}
                    </Button>
                  </div>
                )}

                {/* Comments List */}
                {isLoadingComments ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                  </div>
                ) : comments.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No comments yet. Be the first to comment!
                  </p>
                ) : (
                  <div className="space-y-4">
                    {comments.map((comment) => (
                      <div key={comment.id} className="border-t pt-4">
                        <p className="text-sm">{comment.content}</p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {new Date(comment.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Artwork Info */}
            <Card>
              <CardHeader>
                <CardTitle>{artwork.title}</CardTitle>
                <CardDescription>{artwork.category}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{artwork.description}</p>

                {artwork.tags && (
                  <div className="flex flex-wrap gap-2">
                    {JSON.parse(artwork.tags || "[]").map((tag: string) => (
                      <Badge key={tag} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}

                <div className="text-3xl font-bold text-primary">
                  ${artwork.price.toFixed(2)}
                </div>

                <Button className="w-full" size="lg">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Request Purchase
                </Button>
              </CardContent>
            </Card>

            {/* Artist Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Artist</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={artwork.artist?.profilePictureUrl} />
                    <AvatarFallback>{artwork.artist?.name?.[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">{artwork.artist?.name}</p>
                    <p className="text-xs text-muted-foreground">Artist</p>
                  </div>
                </div>

                {user?.id !== artwork.artistId && (
                  <Button onClick={handleFollow} className="w-full" variant="outline">
                    Follow Artist
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
